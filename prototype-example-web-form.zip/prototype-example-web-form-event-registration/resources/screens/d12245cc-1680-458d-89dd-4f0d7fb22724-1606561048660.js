jQuery("#simulation")
  .on("click", ".s-d12245cc-1680-458d-89dd-4f0d7fb22724 .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Paragraph_19")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Paragraph_12" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Input_2",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Paragraph_11" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Input_1",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Paragraph_11","#s-Paragraph_12" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimMove",
                  "parameter": {
                    "target": [ "#s-Paragraph_12" ],
                    "top": {
                      "type": "movetoposition",
                      "value": "173"
                    },
                    "left": {
                      "type": "movetoposition",
                      "value": "111"
                    },
                    "containment": false,
                    "effect": {
                      "type": "none",
                      "easing": "swing",
                      "duration": 700
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimMove",
                  "parameter": {
                    "target": [ "#s-Paragraph_11" ],
                    "top": {
                      "type": "movetoposition",
                      "value": "190"
                    },
                    "left": {
                      "type": "movetoposition",
                      "value": "111"
                    },
                    "containment": false,
                    "effect": {
                      "type": "none",
                      "easing": "swing",
                      "duration": 700
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_10" ],
                    "effect": {
                      "type": "fade",
                      "duration": 500
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Panel_3" ],
                    "transition": {
                      "type": "slideup",
                      "duration": 900
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "parallel",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Rectangle_1","#s-Group_1" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimResize",
                  "parameter": {
                    "target": [ "#s-Rectangle_1" ],
                    "width": {
                      "type": "exprvalue",
                      "value": "2"
                    },
                    "height": {
                      "type": "exprvalue",
                      "value": "111"
                    },
                    "effect": {
                      "type": "none",
                      "easing": "swing",
                      "duration": 500
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Ellipse_7" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_10 svg": {
                      "attributes": {
                        "overlay": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_9": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_9 span": {
                      "attributes": {
                        "color": "#404040"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_2","#s-Input_1" ],
                    "value": ""
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_2": {
                      "attributes": {
                        "opacity": "0.5"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_2 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#D9D9D9",
                        "border-right-color": "#D9D9D9",
                        "border-bottom-color": "#D9D9D9",
                        "border-left-color": "#D9D9D9"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_2": {
                      "attributes-ie": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_1": {
                      "attributes": {
                        "opacity": "0.5"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_1 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#D9D9D9",
                        "border-right-color": "#D9D9D9",
                        "border-bottom-color": "#D9D9D9",
                        "border-left-color": "#D9D9D9"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_1": {
                      "attributes-ie": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Paragraph_21" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Paragraph_24")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Paragraph_13" ],
                    "value": {
                      "action": "jimConcat",
                      "parameter": [ {
                        "datatype": "variable",
                        "element": "Participants"
                      }," participants" ]
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Paragraph_13" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimMove",
                  "parameter": {
                    "target": [ "#s-Paragraph_13" ],
                    "top": {
                      "type": "movetoposition",
                      "value": "260"
                    },
                    "left": {
                      "type": "movetoposition",
                      "value": "111"
                    },
                    "containment": false,
                    "effect": {
                      "type": "none",
                      "easing": "swing",
                      "duration": 700
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_9" ],
                    "effect": {
                      "type": "fade",
                      "duration": 500
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Panel_5" ],
                    "transition": {
                      "type": "slideup",
                      "duration": 900
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "parallel",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Group_2" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimResize",
                  "parameter": {
                    "target": [ "#s-Rectangle_1" ],
                    "width": {
                      "type": "exprvalue",
                      "value": "2"
                    },
                    "height": {
                      "type": "exprvalue",
                      "value": "200"
                    },
                    "effect": {
                      "type": "none",
                      "easing": "swing",
                      "duration": 500
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Ellipse_5" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_9 svg": {
                      "attributes": {
                        "overlay": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_8": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_8 span": {
                      "attributes": {
                        "color": "#404040"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimMove",
                  "parameter": {
                    "target": [ "#s-Image_15" ],
                    "top": {
                      "type": "movetoposition",
                      "value": "18"
                    },
                    "left": {
                      "type": "movetoposition",
                      "value": "0"
                    },
                    "containment": false
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_28","#s-Paragraph_29","#s-Paragraph_30","#s-Paragraph_31" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Paragraph_27" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #shapewrapper-s-Ellipse_17 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #shapewrapper-s-Ellipse_19 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #shapewrapper-s-Ellipse_18 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #shapewrapper-s-Ellipse_16 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#BDD0D8"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Paragraph_35")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Paragraph_14" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimMove",
                  "parameter": {
                    "target": [ "#s-Paragraph_14" ],
                    "top": {
                      "type": "movetoposition",
                      "value": "347"
                    },
                    "left": {
                      "type": "movetoposition",
                      "value": "111"
                    },
                    "containment": false,
                    "effect": {
                      "type": "none",
                      "easing": "swing",
                      "duration": 700
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_8" ],
                    "effect": {
                      "type": "fade",
                      "duration": 500
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Panel_7" ],
                    "transition": {
                      "type": "slideup",
                      "duration": 900
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "parallel",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Group_3" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimResize",
                  "parameter": {
                    "target": [ "#s-Rectangle_1" ],
                    "width": {
                      "type": "exprvalue",
                      "value": "2"
                    },
                    "height": {
                      "type": "exprvalue",
                      "value": "285"
                    },
                    "effect": {
                      "type": "none",
                      "easing": "swing",
                      "duration": 500
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Ellipse_9" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_8 svg": {
                      "attributes": {
                        "overlay": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_7": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_7 span": {
                      "attributes": {
                        "color": "#404040"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_5": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_5 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_5 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_5 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_2": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_2 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_2 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_2 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_3": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_3 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_3 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_3 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_7": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_7 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_7 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_7 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_9": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_9 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_9 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_9 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_8": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_8 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_8 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_8 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_4": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_4 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_4 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_4 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_6": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_6 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_6 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_6 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_23 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_20 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_16 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_19 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_18 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_22 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_21 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_17 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Hotspot_1")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_2": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_2 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#68D4FF",
                        "border-right-width": "1px",
                        "border-right-color": "#68D4FF",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#68D4FF",
                        "border-left-width": "1px",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_2 span": {
                      "attributes": {
                        "color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_2 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#68D4FF",
                        "border-right-width": "1px",
                        "border-right-color": "#68D4FF",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#68D4FF",
                        "border-left-width": "1px",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_16 svg": {
                      "attributes": {
                        "overlay": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_5": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_5 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_5 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_5 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_3": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_3 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_3 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_3 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_7": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_7 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_7 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_7 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_9": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_9 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_9 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_9 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_8": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_8 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_8 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_8 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_4": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_4 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_4 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_4 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_6": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_6 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_6 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_6 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_23 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_20 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_18 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_19 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_22 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_21 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_17 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_36" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Paragraph_14" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Rectangle_2",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Hotspot_2")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_3": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_3 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#68D4FF",
                        "border-right-width": "1px",
                        "border-right-color": "#68D4FF",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#68D4FF",
                        "border-left-width": "1px",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_3 span": {
                      "attributes": {
                        "color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_3 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#68D4FF",
                        "border-right-width": "1px",
                        "border-right-color": "#68D4FF",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#68D4FF",
                        "border-left-width": "1px",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_17 svg": {
                      "attributes": {
                        "overlay": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_5": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_5 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_5 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_5 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_2": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_2 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_2 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_2 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_7": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_7 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_7 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_7 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_9": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_9 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_9 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_9 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_8": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_8 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_8 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_8 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_4": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_4 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_4 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_4 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_6": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_6 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_6 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_6 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_23 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_20 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_16 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_18 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_19 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_22 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_21 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_36" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Paragraph_14" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Rectangle_3",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Hotspot_3")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_4": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_4 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#68D4FF",
                        "border-right-width": "1px",
                        "border-right-color": "#68D4FF",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#68D4FF",
                        "border-left-width": "1px",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_4 span": {
                      "attributes": {
                        "color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_4 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#68D4FF",
                        "border-right-width": "1px",
                        "border-right-color": "#68D4FF",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#68D4FF",
                        "border-left-width": "1px",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_18 svg": {
                      "attributes": {
                        "overlay": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_5": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_5 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_5 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_5 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_2": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_2 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_2 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_2 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_3": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_3 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_3 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_3 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_7": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_7 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_7 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_7 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_9": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_9 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_9 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_9 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_8": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_8 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_8 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_8 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_6": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_6 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_6 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_6 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_23 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_20 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_16 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_19 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_22 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_21 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_17 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_36" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Paragraph_14" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Rectangle_4",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Hotspot_4")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_5": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_5 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#68D4FF",
                        "border-right-width": "1px",
                        "border-right-color": "#68D4FF",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#68D4FF",
                        "border-left-width": "1px",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_5 span": {
                      "attributes": {
                        "color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_5 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#68D4FF",
                        "border-right-width": "1px",
                        "border-right-color": "#68D4FF",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#68D4FF",
                        "border-left-width": "1px",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_19 svg": {
                      "attributes": {
                        "overlay": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_2": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_2 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_2 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_2 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_3": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_3 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_3 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_3 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_7": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_7 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_7 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_7 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_9": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_9 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_9 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_9 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_8": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_8 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_8 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_8 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_4": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_4 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_4 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_4 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_6": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_6 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_6 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_6 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_23 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_20 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_16 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_18 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_22 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_21 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_17 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_36" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Paragraph_14" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Rectangle_5",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Hotspot_5")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_6": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_6 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#68D4FF",
                        "border-right-width": "1px",
                        "border-right-color": "#68D4FF",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#68D4FF",
                        "border-left-width": "1px",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_6 span": {
                      "attributes": {
                        "color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_6 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#68D4FF",
                        "border-right-width": "1px",
                        "border-right-color": "#68D4FF",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#68D4FF",
                        "border-left-width": "1px",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_20 svg": {
                      "attributes": {
                        "overlay": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_2": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_2 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_2 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_2 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_5": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_5 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_5 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_5 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_3": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_3 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_3 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_3 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_7": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_7 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_7 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_7 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_9": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_9 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_9 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_9 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_8": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_8 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_8 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_8 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_4": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_4 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_4 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_4 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_23 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_16 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_18 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_19 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_22 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_21 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_17 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_36" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Paragraph_14" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Rectangle_6",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Hotspot_6")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_7": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_7 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#68D4FF",
                        "border-right-width": "1px",
                        "border-right-color": "#68D4FF",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#68D4FF",
                        "border-left-width": "1px",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_7 span": {
                      "attributes": {
                        "color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_7 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#68D4FF",
                        "border-right-width": "1px",
                        "border-right-color": "#68D4FF",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#68D4FF",
                        "border-left-width": "1px",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_21 svg": {
                      "attributes": {
                        "overlay": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_2": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_2 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_2 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_2 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_5": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_5 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_5 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_5 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_3": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_3 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_3 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_3 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_9": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_9 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_9 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_9 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_8": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_8 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_8 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_8 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_4": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_4 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_4 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_4 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_6": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_6 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_6 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_6 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_23 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_16 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_20 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_18 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_19 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_22 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_17 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_36" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Paragraph_14" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Rectangle_7",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Hotspot_7")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_8": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_8 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#68D4FF",
                        "border-right-width": "1px",
                        "border-right-color": "#68D4FF",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#68D4FF",
                        "border-left-width": "1px",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_8 span": {
                      "attributes": {
                        "color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_8 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#68D4FF",
                        "border-right-width": "1px",
                        "border-right-color": "#68D4FF",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#68D4FF",
                        "border-left-width": "1px",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_22 svg": {
                      "attributes": {
                        "overlay": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_2": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_2 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_2 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_2 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_5": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_5 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_5 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_5 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_3": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_3 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_3 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_3 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_7": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_7 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_7 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_7 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_9": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_9 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_9 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_9 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_4": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_4 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_4 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_4 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_6": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_6 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_6 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_6 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_23 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_16 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_20 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_18 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_19 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_21 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_17 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_36" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Paragraph_14" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Rectangle_8",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Hotspot_8")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_9": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_9 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#68D4FF",
                        "border-right-width": "1px",
                        "border-right-color": "#68D4FF",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#68D4FF",
                        "border-left-width": "1px",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_9 span": {
                      "attributes": {
                        "color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_9 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#68D4FF",
                        "border-right-width": "1px",
                        "border-right-color": "#68D4FF",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#68D4FF",
                        "border-left-width": "1px",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_23 svg": {
                      "attributes": {
                        "overlay": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_2": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_2 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_2 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_2 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_5": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_5 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_5 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_5 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_3": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_3 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_3 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_3 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_7": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_7 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_7 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_7 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_4": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_4 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_4 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_4 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_8": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_8 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_8 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_8 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_6": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_6 > .borderLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_6 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_6 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-color": "#BDD0D8",
                        "border-right-width": "1px",
                        "border-right-color": "#BDD0D8",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#BDD0D8",
                        "border-left-width": "1px",
                        "border-left-color": "#BDD0D8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_16 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_20 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_18 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_19 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_22 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_21 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_17 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_36" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Paragraph_14" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Rectangle_9",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Paragraph_39")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Paragraph_16" ],
                    "value": {
                      "action": "jimConcat",
                      "parameter": [ {
                        "action": "jimConcat",
                        "parameter": [ {
                          "action": "jimConcat",
                          "parameter": [ {
                            "datatype": "property",
                            "target": "#s-Input_4",
                            "property": "jimGetValue"
                          },", " ]
                        },{
                          "action": "jimConcat",
                          "parameter": [ {
                            "datatype": "property",
                            "target": "#s-Input_3",
                            "property": "jimGetValue"
                          },", " ]
                        } ]
                      },{
                        "datatype": "property",
                        "target": "#s-Input_5",
                        "property": "jimGetValue"
                      } ]
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_1" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Paragraph_7","#s-Paragraph_9","#s-Paragraph_6","#s-Paragraph_10","#s-Paragraph_8" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "parallel",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Paragraph_69" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Paragraph_12",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Paragraph_68" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Paragraph_11",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Paragraph_70" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Paragraph_13",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Paragraph_71" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Paragraph_14",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Paragraph_72" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Paragraph_15",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Paragraph_73" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Paragraph_16",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "parallel",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Panel_9" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_4","#s-Input_3","#s-Input_5" ],
                    "value": ""
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_4": {
                      "attributes": {
                        "opacity": "0.5"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_4 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#D9D9D9",
                        "border-right-color": "#D9D9D9",
                        "border-bottom-color": "#D9D9D9",
                        "border-left-color": "#D9D9D9"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_4": {
                      "attributes-ie": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_3": {
                      "attributes": {
                        "opacity": "0.5"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_3 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#D9D9D9",
                        "border-right-color": "#D9D9D9",
                        "border-bottom-color": "#D9D9D9",
                        "border-left-color": "#D9D9D9"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_3": {
                      "attributes-ie": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_5": {
                      "attributes": {
                        "opacity": "0.5"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_5 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#D9D9D9",
                        "border-right-color": "#D9D9D9",
                        "border-bottom-color": "#D9D9D9",
                        "border-left-color": "#D9D9D9"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_5": {
                      "attributes-ie": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Paragraph_43","#s-Paragraph_44" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Input_6")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Group_20" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_4" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Paragraph_48")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Paragraph_15" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Input_6",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Paragraph_15" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimMove",
                  "parameter": {
                    "target": [ "#s-Paragraph_15" ],
                    "top": {
                      "type": "movetoposition",
                      "value": "434"
                    },
                    "left": {
                      "type": "movetoposition",
                      "value": "111"
                    },
                    "containment": false,
                    "effect": {
                      "type": "none",
                      "easing": "swing",
                      "duration": 700
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_7" ],
                    "effect": {
                      "type": "fade",
                      "duration": 500
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Panel_6" ],
                    "transition": {
                      "type": "slideup",
                      "duration": 900
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "parallel",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Group_4" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimResize",
                  "parameter": {
                    "target": [ "#s-Rectangle_1" ],
                    "width": {
                      "type": "exprvalue",
                      "value": "2"
                    },
                    "height": {
                      "type": "exprvalue",
                      "value": "375"
                    },
                    "effect": {
                      "type": "none",
                      "easing": "swing",
                      "duration": 500
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Ellipse_8" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_7 svg": {
                      "attributes": {
                        "overlay": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_6": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_6 span": {
                      "attributes": {
                        "color": "#404040"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_6" ],
                    "value": "May / 14 / 2019"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_28")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Group_20" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_4" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_10")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_10": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_10 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_10 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_10 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_10 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_4" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "timed",
                  "delay": 180
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_6" ],
                    "value": "May / 1 / 2019"
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Group_20" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_10": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_10 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "transparent"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_10 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_10 span": {
                      "attributes": {
                        "color": "#404040"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_10 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_11")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_11": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_11 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_11 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_11 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_11 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_4" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "timed",
                  "delay": 180
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_6" ],
                    "value": "May / 2 / 2019"
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Group_20" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_11": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_11 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "transparent"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_11 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_11 span": {
                      "attributes": {
                        "color": "#404040"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_11 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_12")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_12": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_12 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_12 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_12 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_12 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_4" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "timed",
                  "delay": 180
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_6" ],
                    "value": "May / 3 / 2019"
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Group_20" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_12": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_12 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "transparent"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_12 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_12 span": {
                      "attributes": {
                        "color": "#404040"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_12 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_13")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_13": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_13 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_13 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_13 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_13 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_4" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "timed",
                  "delay": 180
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_6" ],
                    "value": "May / 4 / 2019"
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Group_20" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_13": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_13 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "transparent"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_13 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_13 span": {
                      "attributes": {
                        "color": "#404040"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_13 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_14")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_14": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_14 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_14 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_14 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_14 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_4" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "timed",
                  "delay": 180
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_6" ],
                    "value": "May / 5 / 2019"
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Group_20" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_14": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_14 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "transparent"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_14 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_14 span": {
                      "attributes": {
                        "color": "#404040"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_14 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_15")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_15": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_15 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_15 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_15 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_15 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_4" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "timed",
                  "delay": 180
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_6" ],
                    "value": "May / 6 / 2019"
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Group_20" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_15": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_15 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "transparent"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_15 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_15 span": {
                      "attributes": {
                        "color": "#404040"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_15 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_16")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_16": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_16 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_16 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_16 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_16 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_4" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "timed",
                  "delay": 180
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_6" ],
                    "value": "May / 7 / 2019"
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Group_20" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_16": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_16 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "transparent"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_16 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_16 span": {
                      "attributes": {
                        "color": "#404040"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_16 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_17")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_17": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_17 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_17 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_17 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_17 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_4" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "timed",
                  "delay": 180
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_6" ],
                    "value": "May / 8 / 2019"
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Group_20" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_17": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_17 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "transparent"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_17 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_17 span": {
                      "attributes": {
                        "color": "#404040"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_17 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_18")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_18": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_18 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_18 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_18 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_18 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_4" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "timed",
                  "delay": 180
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_6" ],
                    "value": "May / 9 / 2019"
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Group_20" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_18": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_18 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "transparent"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_18 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_18 span": {
                      "attributes": {
                        "color": "#404040"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_18 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_19")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_19": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_19 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_19 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_19 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_19 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_4" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "timed",
                  "delay": 180
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_6" ],
                    "value": "May / 10 / 2019"
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Group_20" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_19": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_19 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "transparent"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_19 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_19 span": {
                      "attributes": {
                        "color": "#404040"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_19 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_20")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_20": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_20 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_20 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_20 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_20 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_4" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "timed",
                  "delay": 180
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_6" ],
                    "value": "May / 11 / 2019"
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Group_20" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_20": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_20 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "transparent"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_20 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_20 span": {
                      "attributes": {
                        "color": "#404040"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_20 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_21")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_21": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_21 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_21 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_21 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_21 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_4" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "timed",
                  "delay": 180
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_6" ],
                    "value": "May / 12 / 2019"
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Group_20" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_21": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_21 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "transparent"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_21 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_21 span": {
                      "attributes": {
                        "color": "#404040"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_21 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_22")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_22": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_22 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_22 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_22 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_22 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_4" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "timed",
                  "delay": 180
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_6" ],
                    "value": "May / 13 / 2019"
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Group_20" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_22": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_22 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "transparent"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_22 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_22 span": {
                      "attributes": {
                        "color": "#404040"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_22 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_24")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_24": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_24 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_24 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_24 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_24 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_4" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "timed",
                  "delay": 180
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_6" ],
                    "value": "May / 15 / 2019"
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_49" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_24": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_24 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "transparent"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_24 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_24 span": {
                      "attributes": {
                        "color": "#404040"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_24 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_25")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_25": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_25 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_25 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_25 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_25 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_4" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "timed",
                  "delay": 180
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_6" ],
                    "value": "May / 16 / 2019"
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_49" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_25": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_25 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "transparent"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_25 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_25 span": {
                      "attributes": {
                        "color": "#404040"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_25 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_26")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_26": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_26 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_26 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_26 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_26 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_4" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "timed",
                  "delay": 180
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_6" ],
                    "value": "May / 17 / 2019"
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_49" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_26": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_26 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "transparent"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_26 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_26 span": {
                      "attributes": {
                        "color": "#404040"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_26 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_27")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_27": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_27 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_27 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_27 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_27 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_4" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "timed",
                  "delay": 180
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_6" ],
                    "value": "May / 18 / 2019"
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_49" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_27": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_27 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "transparent"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_27 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_27 span": {
                      "attributes": {
                        "color": "#404040"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_27 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_28")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_28": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_28 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_28 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_28 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_28 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_4" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "timed",
                  "delay": 180
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_6" ],
                    "value": "May / 19 / 2019"
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_49" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_28": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_28 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "transparent"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_28 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_28 span": {
                      "attributes": {
                        "color": "#404040"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_28 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_29")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_29": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_29 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_29 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_29 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_29 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_4" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "timed",
                  "delay": 180
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_6" ],
                    "value": "May / 20 / 2019"
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_49" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_29": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_29 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "transparent"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_29 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_29 span": {
                      "attributes": {
                        "color": "#404040"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_29 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_30")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_30": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_30 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_30 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_30 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_30 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_4" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "timed",
                  "delay": 180
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_6" ],
                    "value": "May / 21 / 2019"
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_49" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_30": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_30 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "transparent"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_30 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_30 span": {
                      "attributes": {
                        "color": "#404040"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_30 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_31")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_31": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_31 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_31 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_31 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_31 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_4" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "timed",
                  "delay": 180
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_6" ],
                    "value": "May / 22 / 2019"
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_49" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_31": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_31 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "transparent"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_31 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_31 span": {
                      "attributes": {
                        "color": "#404040"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_31 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_32")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_32": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_32 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_32 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_32 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_32 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_4" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "timed",
                  "delay": 180
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_6" ],
                    "value": "May / 23 / 2019"
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_49" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_32": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_32 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "transparent"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_32 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_32 span": {
                      "attributes": {
                        "color": "#404040"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_32 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_33")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_33": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_33 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_33 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_33 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_33 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_4" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "timed",
                  "delay": 180
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_6" ],
                    "value": "May / 24 / 2019"
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_49" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_33": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_33 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "transparent"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_33 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_33 span": {
                      "attributes": {
                        "color": "#404040"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_33 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_34")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_34": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_34 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_34 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_34 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_34 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_4" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "timed",
                  "delay": 180
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_6" ],
                    "value": "May / 25 / 2019"
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_49" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_34": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_34 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "transparent"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_34 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_34 span": {
                      "attributes": {
                        "color": "#404040"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_34 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_35")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_35": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_35 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_35 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_35 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_35 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_4" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "timed",
                  "delay": 180
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_6" ],
                    "value": "May / 26 / 2019"
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_49" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_35": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_35 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "transparent"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_35 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_35 span": {
                      "attributes": {
                        "color": "#404040"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_35 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_36")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_36": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_36 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_36 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_36 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_36 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_4" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "timed",
                  "delay": 180
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_6" ],
                    "value": "May / 27 / 2019"
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_49" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_36": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_36 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "transparent"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_36 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_36 span": {
                      "attributes": {
                        "color": "#404040"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_36 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_37")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_37": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_37 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_37 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_37 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_37 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_4" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "timed",
                  "delay": 180
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_6" ],
                    "value": "May / 28 / 2019"
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_49" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_37": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_37 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "transparent"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_37 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_37 span": {
                      "attributes": {
                        "color": "#404040"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_37 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_38")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_38": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_38 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_38 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_38 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_38 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_4" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "timed",
                  "delay": 180
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_6" ],
                    "value": "May / 29 / 2019"
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_49" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_38": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_38 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "transparent"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_38 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_38 span": {
                      "attributes": {
                        "color": "#404040"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_38 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_39")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_39": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_39 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_39 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_39 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_39 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_4" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "timed",
                  "delay": 180
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_6" ],
                    "value": "May / 30 / 2019"
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_49" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_39": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_39 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "transparent"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_39 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_39 span": {
                      "attributes": {
                        "color": "#404040"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_39 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_40")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_40": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_40 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_40 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_40 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_40 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#68D4FF",
                        "border-right-color": "#68D4FF",
                        "border-bottom-color": "#68D4FF",
                        "border-left-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_4" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "timed",
                  "delay": 180
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_6" ],
                    "value": "May / 31 / 2019"
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_49" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_40": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_40 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "transparent"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_40 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_40 span": {
                      "attributes": {
                        "color": "#404040"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_40 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#FFFFFF",
                        "border-right-color": "#FFFFFF",
                        "border-bottom-color": "#FFFFFF",
                        "border-left-color": "#FFFFFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Paragraph_74")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Panel_2" ],
                    "transition": {
                      "type": "fade",
                      "duration": 700
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Paragraph_10","#s-Paragraph_12" ],
                    "value": "Your name"
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Paragraph_11" ],
                    "value": "Lastname"
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Paragraph_9","#s-Paragraph_13" ],
                    "value": "Participants"
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Paragraph_14","#s-Paragraph_8" ],
                    "value": "Event theme"
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Paragraph_15","#s-Paragraph_7" ],
                    "value": "Date"
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Paragraph_16","#s-Paragraph_6" ],
                    "value": "Location"
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_1" ],
                    "effect": {
                      "type": "fade",
                      "easing": "swing",
                      "duration": 500
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimResize",
                  "parameter": {
                    "target": [ "#s-Rectangle_1" ],
                    "width": {
                      "type": "exprvalue",
                      "value": "2"
                    },
                    "height": {
                      "type": "exprvalue",
                      "value": "3"
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Group_4","#s-Paragraph_15","#s-Group_5","#s-Ellipse_7","#s-Paragraph_16","#s-Paragraph_14","#s-Paragraph_13","#s-Ellipse_9","#s-Paragraph_11","#s-Group_3","#s-Group_1","#s-Ellipse_8","#s-Group_2","#s-Ellipse_5","#s-Paragraph_12" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_61","#s-Paragraph_63","#s-Paragraph_62","#s-Paragraph_64","#s-Paragraph_66","#s-Paragraph_74","#s-Paragraph_69","#s-Image_33","#s-Paragraph_72","#s-Image_34","#s-Paragraph_71","#s-Paragraph_67","#s-Paragraph_73","#s-Line_4","#s-Line_3","#s-Image_37","#s-Line_6","#s-Paragraph_70","#s-Paragraph_68","#s-Image_36","#s-Line_5","#s-Paragraph_65","#s-Image_35" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimMove",
                  "parameter": {
                    "target": [ "#s-Paragraph_12" ],
                    "top": {
                      "type": "movetoposition",
                      "value": "326"
                    },
                    "left": {
                      "type": "movetoposition",
                      "value": "461"
                    },
                    "containment": false
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimMove",
                  "parameter": {
                    "target": [ "#s-Paragraph_11" ],
                    "top": {
                      "type": "movetoposition",
                      "value": "326"
                    },
                    "left": {
                      "type": "movetoposition",
                      "value": "730"
                    },
                    "containment": false
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimMove",
                  "parameter": {
                    "target": [ "#s-Paragraph_13" ],
                    "top": {
                      "type": "movetoposition",
                      "value": "337"
                    },
                    "left": {
                      "type": "movetoposition",
                      "value": "797"
                    },
                    "containment": false
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimMove",
                  "parameter": {
                    "target": [ "#s-Paragraph_14" ],
                    "top": {
                      "type": "movetoposition",
                      "value": "342"
                    },
                    "left": {
                      "type": "movetoposition",
                      "value": "661"
                    },
                    "containment": false
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimMove",
                  "parameter": {
                    "target": [ "#s-Paragraph_15" ],
                    "top": {
                      "type": "movetoposition",
                      "value": "326"
                    },
                    "left": {
                      "type": "movetoposition",
                      "value": "468"
                    },
                    "containment": false
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimMove",
                  "parameter": {
                    "target": [ "#s-Paragraph_16" ],
                    "top": {
                      "type": "movetoposition",
                      "value": "521"
                    },
                    "left": {
                      "type": "movetoposition",
                      "value": "463"
                    },
                    "containment": false
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_7": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_7 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_9": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_9 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_6": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_6 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_8": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_8 span": {
                      "attributes": {
                        "color": "#BDD0D8"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_10": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_10 span": {
                      "attributes": {
                        "color": "#404040"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimMove",
                  "parameter": {
                    "target": [ "#s-Image_32" ],
                    "top": {
                      "type": "movetoposition",
                      "value": "-266"
                    },
                    "left": {
                      "type": "movetoposition",
                      "value": "839"
                    },
                    "containment": false
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimMove",
                  "parameter": {
                    "target": [ "#s-Image_31" ],
                    "top": {
                      "type": "movetoposition",
                      "value": "729"
                    },
                    "left": {
                      "type": "movetoposition",
                      "value": "10"
                    },
                    "containment": false
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("mouseup", ".s-d12245cc-1680-458d-89dd-4f0d7fb22724 .mouseup", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Paragraph_19")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_19": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_19 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Paragraph_24")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_24": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_24 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Paragraph_35")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_35": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_35 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Paragraph_39")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_39": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_39 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Paragraph_48")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_48": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_48 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#68D4FF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("mousedown", ".s-d12245cc-1680-458d-89dd-4f0d7fb22724 .mousedown", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Paragraph_19")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_19": {
                      "attributes": {
                        "filter": "none",
                        "text-shadow": "none",
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_19 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#62ACDC"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Paragraph_24")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_24": {
                      "attributes": {
                        "filter": "none",
                        "text-shadow": "none",
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_24 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#62ACDC"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Paragraph_35")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_35": {
                      "attributes": {
                        "filter": "none",
                        "text-shadow": "none",
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_35 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#62ACDC"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Paragraph_39")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_39": {
                      "attributes": {
                        "filter": "none",
                        "text-shadow": "none",
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_39 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#62ACDC"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Paragraph_48")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_48": {
                      "attributes": {
                        "filter": "none",
                        "text-shadow": "none",
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_48 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#62ACDC"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("drag", ".s-d12245cc-1680-458d-89dd-4f0d7fb22724 .drag", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getDirectEventFirer(this);
    if(jFirer.is("#s-Image_15")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimInsert",
                  "parameter": {
                    "target": [ "#s-Image_15" ],
                    "parent": "#s-Panel_4"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimMove",
                  "parameter": {
                    "target": [ "#s-Image_15" ],
                    "top": {
                      "type": "nomove"
                    },
                    "left": {
                      "type": "movewithcursor",
                      "value": null
                    },
                    "containment": true
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_15 svg": {
                      "attributes": {
                        "overlay": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "condition": {
                "action": "jimAnd",
                "parameter": [ {
                  "action": "jimGreater",
                  "parameter": [ {
                    "datatype": "property",
                    "target": "#s-Image_15",
                    "property": "jimGetPositionX"
                  },"30" ]
                },{
                  "action": "jimLess",
                  "parameter": [ {
                    "datatype": "property",
                    "target": "#s-Image_15",
                    "property": "jimGetPositionX"
                  },"110" ]
                } ]
              },
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_30","#s-Paragraph_27","#s-Paragraph_28","#s-Paragraph_31" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Paragraph_29" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "condition": {
                "action": "jimAnd",
                "parameter": [ {
                  "action": "jimGreater",
                  "parameter": [ {
                    "datatype": "property",
                    "target": "#s-Image_15",
                    "property": "jimGetPositionX"
                  },"110" ]
                },{
                  "action": "jimLess",
                  "parameter": [ {
                    "datatype": "property",
                    "target": "#s-Image_15",
                    "property": "jimGetPositionX"
                  },"185" ]
                } ]
              },
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_30","#s-Paragraph_27","#s-Paragraph_29","#s-Paragraph_31" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Paragraph_28" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "condition": {
                "action": "jimAnd",
                "parameter": [ {
                  "action": "jimGreater",
                  "parameter": [ {
                    "datatype": "property",
                    "target": "#s-Image_15",
                    "property": "jimGetPositionX"
                  },"185" ]
                },{
                  "action": "jimLess",
                  "parameter": [ {
                    "datatype": "property",
                    "target": "#s-Image_15",
                    "property": "jimGetPositionX"
                  },"260" ]
                } ]
              },
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_27","#s-Paragraph_28","#s-Paragraph_29","#s-Paragraph_31" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Paragraph_30" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "condition": {
                "action": "jimGreater",
                "parameter": [ {
                  "datatype": "property",
                  "target": "#s-Image_15",
                  "property": "jimGetPositionX"
                },"260" ]
              },
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_30","#s-Paragraph_27","#s-Paragraph_28","#s-Paragraph_29" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Paragraph_31" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "condition": {
                "action": "jimLess",
                "parameter": [ {
                  "datatype": "property",
                  "target": "#s-Image_15",
                  "property": "jimGetPositionX"
                },"30" ]
              },
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_30","#s-Paragraph_28","#s-Paragraph_29","#s-Paragraph_31" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Paragraph_27" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("dragend", ".s-d12245cc-1680-458d-89dd-4f0d7fb22724 .drag", function(event, data) {
    jimEvent(event).jimRestoreDrag(jQuery(this));
  })
  .on("dragend", ".s-d12245cc-1680-458d-89dd-4f0d7fb22724 .dragend", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getDirectEventFirer(this);
    if(jFirer.is("#s-Image_15")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Image_15 svg": {
                      "attributes": {
                        "overlay": "#BDD0D8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "condition": {
                "action": "jimLess",
                "parameter": [ {
                  "datatype": "property",
                  "target": "#s-Image_15",
                  "property": "jimGetPositionX"
                },"30" ]
              },
              "actions": [
                {
                  "action": "jimMove",
                  "parameter": {
                    "target": [ "#s-Image_15" ],
                    "top": {
                      "type": "nomove"
                    },
                    "left": {
                      "type": "movetoposition",
                      "value": "0"
                    },
                    "containment": false
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #shapewrapper-s-Ellipse_17 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #shapewrapper-s-Ellipse_19 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #shapewrapper-s-Ellipse_18 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #shapewrapper-s-Ellipse_16 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#BDD0D8"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Group_8","#s-Paragraph_25" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "condition": {
                "action": "jimAnd",
                "parameter": [ {
                  "action": "jimGreater",
                  "parameter": [ {
                    "datatype": "property",
                    "target": "#s-Image_15",
                    "property": "jimGetPositionX"
                  },"30" ]
                },{
                  "action": "jimLess",
                  "parameter": [ {
                    "datatype": "property",
                    "target": "#s-Image_15",
                    "property": "jimGetPositionX"
                  },"110" ]
                } ]
              },
              "actions": [
                {
                  "action": "jimMove",
                  "parameter": {
                    "target": [ "#s-Image_15" ],
                    "top": {
                      "type": "nomove"
                    },
                    "left": {
                      "type": "movetoposition",
                      "value": "74"
                    },
                    "containment": false
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #shapewrapper-s-Ellipse_16 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #shapewrapper-s-Ellipse_17 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #shapewrapper-s-Ellipse_19 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #shapewrapper-s-Ellipse_18 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#BDD0D8"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Group_8","#s-Paragraph_25" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "Participants" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Paragraph_29",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "condition": {
                "action": "jimAnd",
                "parameter": [ {
                  "action": "jimGreater",
                  "parameter": [ {
                    "datatype": "property",
                    "target": "#s-Image_15",
                    "property": "jimGetPositionX"
                  },"110" ]
                },{
                  "action": "jimLess",
                  "parameter": [ {
                    "datatype": "property",
                    "target": "#s-Image_15",
                    "property": "jimGetPositionX"
                  },"185" ]
                } ]
              },
              "actions": [
                {
                  "action": "jimMove",
                  "parameter": {
                    "target": [ "#s-Image_15" ],
                    "top": {
                      "type": "nomove"
                    },
                    "left": {
                      "type": "movetoposition",
                      "value": "149"
                    },
                    "containment": false
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #shapewrapper-s-Ellipse_17 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #shapewrapper-s-Ellipse_19 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #shapewrapper-s-Ellipse_18 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #shapewrapper-s-Ellipse_16 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#BDD0D8"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Group_8","#s-Paragraph_25" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "Participants" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Paragraph_28",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "condition": {
                "action": "jimAnd",
                "parameter": [ {
                  "action": "jimGreater",
                  "parameter": [ {
                    "datatype": "property",
                    "target": "#s-Image_15",
                    "property": "jimGetPositionX"
                  },"185" ]
                },{
                  "action": "jimLess",
                  "parameter": [ {
                    "datatype": "property",
                    "target": "#s-Image_15",
                    "property": "jimGetPositionX"
                  },"260" ]
                } ]
              },
              "actions": [
                {
                  "action": "jimMove",
                  "parameter": {
                    "target": [ "#s-Image_15" ],
                    "top": {
                      "type": "nomove"
                    },
                    "left": {
                      "type": "movetoposition",
                      "value": "225"
                    },
                    "containment": false
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #shapewrapper-s-Ellipse_18 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #shapewrapper-s-Ellipse_17 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #shapewrapper-s-Ellipse_19 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #shapewrapper-s-Ellipse_16 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#BDD0D8"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Group_8","#s-Paragraph_25" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "Participants" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Paragraph_30",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "condition": {
                "action": "jimGreater",
                "parameter": [ {
                  "datatype": "property",
                  "target": "#s-Image_15",
                  "property": "jimGetPositionX"
                },"260" ]
              },
              "actions": [
                {
                  "action": "jimMove",
                  "parameter": {
                    "target": [ "#s-Image_15" ],
                    "top": {
                      "type": "nomove"
                    },
                    "left": {
                      "type": "movetoposition",
                      "value": "303"
                    },
                    "containment": false
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #shapewrapper-s-Ellipse_19 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #shapewrapper-s-Ellipse_17 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #shapewrapper-s-Ellipse_18 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#BDD0D8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #shapewrapper-s-Ellipse_16 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#BDD0D8"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Group_8","#s-Paragraph_25" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "Participants" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Paragraph_31",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "condition": {
                "action": "jimNot",
                "parameter": [ {
                  "datatype": "property",
                  "target": "#s-Group_8",
                  "property": "jimIsVisible"
                } ]
              },
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_25" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("dragend", ".s-d12245cc-1680-458d-89dd-4f0d7fb22724 .drag", function(event, data) {
    jimEvent(event).jimDestroyDrag(jQuery(this));
  })
  .on("keyup.jim", ".s-d12245cc-1680-458d-89dd-4f0d7fb22724 .keyup", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Input_1")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimAnd",
                "parameter": [ {
                  "action": "jimRegExp",
                  "parameter": [ {
                    "datatype": "property",
                    "target": "#s-Input_1",
                    "property": "jimGetValue"
                  },"^[a-zA-Z]+$" ]
                },{
                  "action": "jimRegExp",
                  "parameter": [ {
                    "datatype": "property",
                    "target": "#s-Input_1",
                    "property": "jimGetValue"
                  },"^.{3,99}$" ]
                } ]
              },
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Group_7","#s-Paragraph_20" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Paragraph_20" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      if(!jimUtil.isAndroidDevice() || data.which != 229)
      	jEvent.launchCases(cases);
      if(data.which === 9) {
        return false;
      }
    } else if(jFirer.is("#s-Input_2")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimAnd",
                "parameter": [ {
                  "action": "jimRegExp",
                  "parameter": [ {
                    "datatype": "property",
                    "target": "#s-Input_2",
                    "property": "jimGetValue"
                  },"^[a-zA-Z]+$" ]
                },{
                  "action": "jimRegExp",
                  "parameter": [ {
                    "datatype": "property",
                    "target": "#s-Input_2",
                    "property": "jimGetValue"
                  },"^.{3,99}$" ]
                } ]
              },
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_21","#s-Group_6" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Paragraph_21" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      if(!jimUtil.isAndroidDevice() || data.which != 229)
      	jEvent.launchCases(cases);
      if(data.which === 9) {
        return false;
      }
    } else if(jFirer.is("#s-Input_3")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimAnd",
                "parameter": [ {
                  "action": "jimRegExp",
                  "parameter": [ {
                    "datatype": "property",
                    "target": "#s-Input_3",
                    "property": "jimGetValue"
                  },"^[a-zA-Z][a-zA-Z\\s]*$" ]
                },{
                  "action": "jimRegExp",
                  "parameter": [ {
                    "datatype": "property",
                    "target": "#s-Input_3",
                    "property": "jimGetValue"
                  },"^.{3,99}$" ]
                } ]
              },
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Group_18","#s-Paragraph_43" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Paragraph_43" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      if(!jimUtil.isAndroidDevice() || data.which != 229)
      	jEvent.launchCases(cases);
      if(data.which === 9) {
        return false;
      }
    } else if(jFirer.is("#s-Input_4")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimRegExp",
                "parameter": [ {
                  "datatype": "property",
                  "target": "#s-Input_4",
                  "property": "jimGetValue"
                },"^.{3,99}$" ]
              },
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_44","#s-Group_17" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Paragraph_44" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      if(!jimUtil.isAndroidDevice() || data.which != 229)
      	jEvent.launchCases(cases);
      if(data.which === 9) {
        return false;
      }
    } else if(jFirer.is("#s-Input_5")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimRegExp",
                "parameter": [ {
                  "datatype": "property",
                  "target": "#s-Input_5",
                  "property": "jimGetValue"
                },"^\\d{3,}$" ]
              },
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Group_19","#s-Paragraph_40" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Paragraph_40","#s-Group_19" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      if(!jimUtil.isAndroidDevice() || data.which != 229)
      	jEvent.launchCases(cases);
      if(data.which === 9) {
        return false;
      }
    }
  })
  .on("pageload", ".s-d12245cc-1680-458d-89dd-4f0d7fb22724 .pageload", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Input_6")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_6" ],
                    "value": "May / 14 / 2019"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("focusin", ".s-d12245cc-1680-458d-89dd-4f0d7fb22724 .focusin", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Input_1")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_1": {
                      "attributes": {
                        "opacity": "1.0"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_1 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_1": {
                      "attributes-ie": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=100)",
                        "filter": "alpha(opacity=100)"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Input_2")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_2": {
                      "attributes": {
                        "opacity": "1.0"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_2 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_2": {
                      "attributes-ie": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=100)",
                        "filter": "alpha(opacity=100)"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Input_3")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_3": {
                      "attributes": {
                        "opacity": "1.0"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_3 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_3": {
                      "attributes-ie": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=100)",
                        "filter": "alpha(opacity=100)"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Input_4")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_4": {
                      "attributes": {
                        "opacity": "1.0"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_4 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_4": {
                      "attributes-ie": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=100)",
                        "filter": "alpha(opacity=100)"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Input_5")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_5": {
                      "attributes": {
                        "opacity": "1.0"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_5 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_5": {
                      "attributes-ie": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=100)",
                        "filter": "alpha(opacity=100)"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("focusout", ".s-d12245cc-1680-458d-89dd-4f0d7fb22724 .focusout", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Input_1")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimEquals",
                "parameter": [ {
                  "datatype": "property",
                  "target": "#s-Input_1",
                  "property": "jimGetValue"
                },"" ]
              },
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Group_7" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_1": {
                      "attributes": {
                        "opacity": "0.5"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_1 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#CED4DA",
                        "border-right-color": "#CED4DA",
                        "border-bottom-color": "#CED4DA",
                        "border-left-color": "#CED4DA"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_1": {
                      "attributes-ie": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            },
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Group_7" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_1": {
                      "attributes": {
                        "opacity": "1.0"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_1 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#CED4DA",
                        "border-right-color": "#CED4DA",
                        "border-bottom-color": "#CED4DA",
                        "border-left-color": "#CED4DA"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_1": {
                      "attributes-ie": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=100)",
                        "filter": "alpha(opacity=100)"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Input_2")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimEquals",
                "parameter": [ {
                  "datatype": "property",
                  "target": "#s-Input_2",
                  "property": "jimGetValue"
                },"" ]
              },
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Group_6" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_2": {
                      "attributes": {
                        "opacity": "0.5"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_2 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#CED4DA",
                        "border-right-color": "#CED4DA",
                        "border-bottom-color": "#CED4DA",
                        "border-left-color": "#CED4DA"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_2": {
                      "attributes-ie": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            },
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Group_6" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_2": {
                      "attributes": {
                        "opacity": "1.0"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_2 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#CED4DA",
                        "border-right-color": "#CED4DA",
                        "border-bottom-color": "#CED4DA",
                        "border-left-color": "#CED4DA"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_2": {
                      "attributes-ie": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=100)",
                        "filter": "alpha(opacity=100)"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Input_3")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimEquals",
                "parameter": [ {
                  "datatype": "property",
                  "target": "#s-Input_3",
                  "property": "jimGetValue"
                },"" ]
              },
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Group_18" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_3": {
                      "attributes": {
                        "opacity": "0.5"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_3 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#CED4DA",
                        "border-right-color": "#CED4DA",
                        "border-bottom-color": "#CED4DA",
                        "border-left-color": "#CED4DA"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_3": {
                      "attributes-ie": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            },
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Group_18" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_3": {
                      "attributes": {
                        "opacity": "1.0"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_3 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#CED4DA",
                        "border-right-color": "#CED4DA",
                        "border-bottom-color": "#CED4DA",
                        "border-left-color": "#CED4DA"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_3": {
                      "attributes-ie": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=100)",
                        "filter": "alpha(opacity=100)"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Input_4")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimEquals",
                "parameter": [ {
                  "datatype": "property",
                  "target": "#s-Input_4",
                  "property": "jimGetValue"
                },"" ]
              },
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Group_17" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_4": {
                      "attributes": {
                        "opacity": "0.5"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_4 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#CED4DA",
                        "border-right-color": "#CED4DA",
                        "border-bottom-color": "#CED4DA",
                        "border-left-color": "#CED4DA"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_4": {
                      "attributes-ie": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            },
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Group_17" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_4": {
                      "attributes": {
                        "opacity": "1.0"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_4 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#CED4DA",
                        "border-right-color": "#CED4DA",
                        "border-bottom-color": "#CED4DA",
                        "border-left-color": "#CED4DA"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_4": {
                      "attributes-ie": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=100)",
                        "filter": "alpha(opacity=100)"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Input_5")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimEquals",
                "parameter": [ {
                  "datatype": "property",
                  "target": "#s-Input_5",
                  "property": "jimGetValue"
                },"" ]
              },
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Group_19" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_5": {
                      "attributes": {
                        "opacity": "0.5"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_5 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#CED4DA",
                        "border-right-color": "#CED4DA",
                        "border-bottom-color": "#CED4DA",
                        "border-left-color": "#CED4DA"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_5": {
                      "attributes-ie": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            },
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Group_19" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_5": {
                      "attributes": {
                        "opacity": "1.0"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_5 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#CED4DA",
                        "border-right-color": "#CED4DA",
                        "border-bottom-color": "#CED4DA",
                        "border-left-color": "#CED4DA"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Input_5": {
                      "attributes-ie": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=100)",
                        "filter": "alpha(opacity=100)"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("mouseenter dragenter", ".s-d12245cc-1680-458d-89dd-4f0d7fb22724 .mouseenter", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getDirectEventFirer(this);
    if(jFirer.is("#s-Paragraph_19") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_19": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_19 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Paragraph_24") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_24": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_24 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Paragraph_35") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_35": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_35 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Paragraph_39") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_39": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_39 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Paragraph_48") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_48": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_48 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_10") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_10": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_10 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_10 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_11") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_11": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_11 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_11 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_12") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_12": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_12 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_12 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_13") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_13": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_13 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_13 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_14") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_14": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_14 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_14 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_15") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_15": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_15 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_15 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_16") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_16": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_16 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_16 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_17") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_17": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_17 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_17 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_18") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_18": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_18 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_18 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_19") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_19": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_19 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_19 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_20") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_20": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_20 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_20 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_21") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_21": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_21 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_21 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_22") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_22": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_22 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_22 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_24") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_24": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_24 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_24 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_25") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_25": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_25 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_25 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_26") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_26": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_26 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_26 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_27") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_27": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_27 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_27 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_28") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_28": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_28 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_28 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_29") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_29": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_29 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_29 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_30") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_30": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_30 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_30 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_31") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_31": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_31 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_31 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_32") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_32": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_32 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_32 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_33") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_33": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_33 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_33 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_34") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_34": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_34 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_34 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_35") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_35": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_35 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_35 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_36") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_36": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_36 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_36 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_37") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_37": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_37 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_37 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_38") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_38": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_38 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_38 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_39") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_39": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_39 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_39 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_40") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_40": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_40 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_40 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#42C4F8",
                        "border-right-color": "#42C4F8",
                        "border-bottom-color": "#42C4F8",
                        "border-left-color": "#42C4F8"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Paragraph_74") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_74": {
                      "attributes": {
                        "opacity": "0.5",
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_74": {
                      "attributes-ie": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Paragraph_74": {
                      "attributes-ie8lte": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_42") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_42": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_42 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#68D4FF"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Rectangle_42 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    }
  })
  .on("mouseleave dragleave", ".s-d12245cc-1680-458d-89dd-4f0d7fb22724 .mouseleave", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getDirectEventFirer(this);
    if(jFirer.is("#s-Paragraph_19")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Paragraph_24")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Paragraph_35")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Paragraph_39")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Paragraph_48")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_10")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_11")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_12")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_13")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_14")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_15")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_16")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_17")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_18")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_19")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_20")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_21")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_22")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_24")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_25")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_26")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_27")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_28")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_29")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_30")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_31")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_32")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_33")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_34")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_35")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_36")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_37")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_38")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_39")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_40")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Paragraph_74")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_42")) {
      jEvent.undoCases(jFirer);
    }
  })
  .on("panelactive", ".s-d12245cc-1680-458d-89dd-4f0d7fb22724 .panelactive", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Panel_9")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimPause",
                  "parameter": {
                    "pause": 400
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimMove",
                  "parameter": {
                    "target": [ "#s-Image_32" ],
                    "top": {
                      "type": "movetoposition",
                      "value": "102"
                    },
                    "left": {
                      "type": "movetoposition",
                      "value": "839"
                    },
                    "containment": false,
                    "effect": {
                      "type": "none",
                      "easing": "easeOutBack",
                      "duration": 450
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Paragraph_62" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 270,
                      "direction": "up"
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Paragraph_61" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 270,
                      "direction": "up"
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Paragraph_63","#s-Paragraph_64","#s-Paragraph_66","#s-Image_33","#s-Image_34","#s-Paragraph_67","#s-Line_4","#s-Line_3","#s-Image_37","#s-Line_6","#s-Image_36","#s-Line_5","#s-Image_35","#s-Paragraph_65" ],
                    "effect": {
                      "type": "fade",
                      "easing": "linear",
                      "duration": 180
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Paragraph_69","#s-Paragraph_72","#s-Paragraph_70","#s-Paragraph_68","#s-Paragraph_71","#s-Paragraph_73" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 270,
                      "direction": "up"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimMove",
                  "parameter": {
                    "target": [ "#s-Image_31" ],
                    "top": {
                      "type": "movetoposition",
                      "value": "410"
                    },
                    "left": {
                      "type": "movetoposition",
                      "value": "10"
                    },
                    "containment": false,
                    "effect": {
                      "type": "none",
                      "easing": "easeOutCirc",
                      "duration": 450
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Paragraph_74" ],
                    "effect": {
                      "type": "fade",
                      "easing": "linear",
                      "duration": 210
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "timed",
          "delay": 500
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  });