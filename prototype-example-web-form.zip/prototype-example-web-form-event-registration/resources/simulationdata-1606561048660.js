function initData() {
  jimData.variables["Participants"] = "";
  jimData.isInitialized = true;
}